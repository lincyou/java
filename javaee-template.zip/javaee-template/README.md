# 服务端

## 1. 项目目录结构


```
- javaee-template:
  - docker: 部署
  - sql: 数据库sql
  - src:
    - ...
      - core 封装层
      - idal 接口层
      - model 实体层
      - orm 数据库层
      - service 业务层
    - resources
        - mybatis
        - application.yml   公共配置
        - application-native.yml 本地开发环境配置
  - pom.xml
```


## 2. 项目须知




## 3. 项目使用的第三方信息


### 3.1 七牛云

> 存储空间：华南区 mw-cdn

| 账号 | 密码 |
| --- | --- |
| macrowolf@126.com | MW20180929b8d. |



```yml
  access:
    key: vmOguAwSF4tTxoV9VIUSIiKh0Yo2rmKh4yPj1qaT
  secret:
    key: BVC8DGFO6aVfCA_k3zTzbV3DaXg9GVaTyPlPdvDp
  bucket: mw-cdn
  domain: https://mw-cdn.macrowolf.cn/
```


### 3.2 服务器

> 供应商：阿里云

| 账号 | 密码 |
| --- | --- |
| macrowolf@126.com | MW20180929b8d. |