package cn.macrowolf.core.constant;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/29 2:10 PM
 */
public final class SystemConstant {
    private SystemConstant(){}

    public static final String SYSTEM_TOKEN_NAME = "X-Access-Token";
}
