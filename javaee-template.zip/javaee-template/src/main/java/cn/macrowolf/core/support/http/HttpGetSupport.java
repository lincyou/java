package cn.macrowolf.core.support.http;

import okhttp3.Request;

import java.util.Map;

/**
 * @author CatalpaFlat
 */
public class HttpGetSupport extends AbstractHttpSupport {

    public static String get(String url) {
        return HttpGetSupport.get(url, "UTF-8", null, null);
    }

    public static String get(String url, String encode) {
        return HttpGetSupport.get(url, encode, null, null);
    }

    public static String getParams(String url, String encode, Map<String, String> paramsMap) {
        return HttpGetSupport.get(url, encode, paramsMap, null);
    }

    public static String getHeards(String url, String encode, Map<String, String> headersMap) {
        return HttpGetSupport.get(url, encode, null, headersMap);
    }

    public static String get(String url, String encode, Map<String, String> paramsMap, Map<String, String> headersMap) {


        Request.Builder requestBuilder = new Request.Builder();


        if (paramsMap != null) {
            requestBuilder.url(obtainHttpUrl(encode, paramsMap));
        }

        if (headersMap != null) {
            requestBuilder.headers(obtainHeaders(headersMap));
        }

        Request request = requestBuilder
                .url(url)
                .get()
                .build();

        return obtainResult(request);
    }

}

