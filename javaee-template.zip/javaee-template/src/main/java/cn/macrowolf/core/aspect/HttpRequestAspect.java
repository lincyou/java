package cn.macrowolf.core.aspect;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.Map;

@Slf4j
@Aspect
@Order(2)
@Component
public class HttpRequestAspect {

    /**
     * 切面
     */
    private final String POINT_CUT = "execution(* cn.macrowolf.draw.idal..*(..))";


    @Pointcut(POINT_CUT)
    private void pointcut() {
    }


    @Before(POINT_CUT)
    public void before(JoinPoint joinPoint) {
        Object[] obj = joinPoint.getArgs();

        ServletRequestAttributes res = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = res.getRequest();
        // 符合API设计规范
        if (obj.length > 0 && obj.length == 1) {
            Object o = obj[0];
            if (!check(o)) {
                // Json params
                if (o != null) {
                    String requestObj = new Gson().toJson(o);
                    log.info("[Params] " + requestObj);
                }
            } else {
                //项目中的定时器在容器加载之前，需要判断
                String query = request.getQueryString();
                StringBuffer requestURL = request.getRequestURL();
                String path = request.getPathInfo();
                String pathTranslated = request.getPathTranslated();
                Map<String, String[]> parameterMap = request.getParameterMap();
                log.info("[Params query] " + "?" + requestURL.toString());
                log.info("[Params query] " + "?" + query);
                log.info("[Params path] " + "?" + path);
                log.info("[Params from] " + "?" + new Gson().toJson(parameterMap));
            }
        } else if (obj.length == 0) {
            log.info("[Params] null");
        }
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            String headValue = request.getHeader(headerName);
            log.info(headerName + "=" + headValue);
        }
    }

    /**
     * mv
     * 后置返回通知
     */
    @AfterReturning(pointcut = POINT_CUT, argNames = "joinPoint, response", returning = "response")
    public void afterReturn(JoinPoint joinPoint, ResponseEntity response) {
        log.info(joinPoint + " Response: " + new Gson().toJson(response) + "\n");
    }

    /**
     * 抛出异常后通知
     */
    @AfterThrowing(pointcut = POINT_CUT, throwing = "ex")
    public void afterThrow(JoinPoint joinPoint, Exception ex) {
        log.error("error:" + ex.getMessage());
        log.error(joinPoint + " Exception: " + ex.getMessage());
    }

    private static boolean check(Object obj) {
        return obj instanceof Integer || obj instanceof Boolean || obj instanceof Double || obj instanceof String || obj instanceof Float;
    }


}
