package cn.macrowolf.core.encrypt;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.AlgorithmParameters;
import java.security.Key;
import java.security.Security;

/**
 * @author ： CatalpaFlat
 * @date ：Create in 11:07 2018/1/26
 */
@Slf4j
public class AESEncrypt {
    /**
     * 加密用的Key 可以用16个字母和数字组成
     * 此处使用AES-128-CBC加密模式，key需要为16位。
     */
    private static final String sKey = "oejQhDLMgOOc4S84";
    private static final String ivParameter = "F0vfau5eVzp6Ohdf";
    private static final String KEY_ALGORITHM = "AES";
    private static final String ECB_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";
    private static final String CBC_CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";

    private static AESEncrypt instance = null;

    private static boolean initialized = false;

    private AESEncrypt() {

    }


    public static AESEncrypt getInstance() {
        if (instance == null) {
            instance = new AESEncrypt();
        }
        return instance;
    }

    public static void main(String[] args) throws Exception {
        log.info(encrypt("admin"));
    }


    /**
     * 加密
     */
    public static String encrypt(String sSrc, String ivStr) throws Exception {
        return e(sSrc, ivStr);
    }

    /**
     * 加密
     */
    public static String encrypt(String sSrc) throws Exception {
        return e(sSrc, null);
    }

    private static String e(String sSrc, String ivStr) throws Exception {
        if (StringUtils.isBlank(ivStr)) {
            ivStr = ivParameter;
        }
        Cipher cipher = Cipher.getInstance(CBC_CIPHER_ALGORITHM);
        byte[] raw = sKey.getBytes();
        SecretKeySpec secretKey = new SecretKeySpec(raw, KEY_ALGORITHM);
        // 使用CBC模式，需要一个向量iv，可增加加密算法的强度
        IvParameterSpec iv = new IvParameterSpec(ivStr.getBytes());
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
        byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));
        // 此处使用BASE64做转码。
        return Base64.encode(encrypted);
    }

    /**
     * 加密
     */
    public static byte[] encryptByte(byte[] sSrc) throws Exception {
        Cipher cipher = Cipher.getInstance(CBC_CIPHER_ALGORITHM);
        byte[] raw = sKey.getBytes();
        SecretKeySpec secretKey = new SecretKeySpec(raw, KEY_ALGORITHM);
        // 使用CBC模式，需要一个向量iv，可增加加密算法的强度
        IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
        return cipher.doFinal(sSrc);
    }

    /**
     * 解密
     */
    public static byte[] decryptByte(byte[] encrypted1) throws Exception {
        try {
            byte[] raw = sKey.getBytes("ASCII");
            SecretKeySpec secretKey = new SecretKeySpec(raw, KEY_ALGORITHM);
            Cipher cipher = Cipher.getInstance(CBC_CIPHER_ALGORITHM);
            IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
            return cipher.doFinal(encrypted1);
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * 解密
     */
    public static String d(String sSrc, String ivStr) throws Exception {
        try {
            if (StringUtils.isBlank(ivStr)) {
                ivStr = ivParameter;
            }
            byte[] raw = sKey.getBytes("ASCII");
            SecretKeySpec secretKey = new SecretKeySpec(raw, KEY_ALGORITHM);
            Cipher cipher = Cipher.getInstance(CBC_CIPHER_ALGORITHM);
            IvParameterSpec iv = new IvParameterSpec(ivStr.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
            // 先用base64解密
            byte[] encrypted1 = Base64.decode(sSrc);
            byte[] original = cipher.doFinal(encrypted1);
            return new String(original, "utf-8");
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * 解密
     */
    public static String decrypt(String sSrc, String ivStr) throws Exception {
        return d(sSrc, ivStr);
    }

    /**
     * 解密
     */
    public static String decrypt(String sSrc) throws Exception {
        return d(sSrc, null);
    }

    /**
     * AES解密
     */
    public static byte[] decrypt(byte[] content, byte[] keyByte, byte[] ivByte) {
        initialize();
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            Key sKeySpec = new SecretKeySpec(keyByte, "AES");
            // 初始化
            cipher.init(Cipher.DECRYPT_MODE, sKeySpec, generateIV(ivByte));
            return cipher.doFinal(content);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void initialize() {
        if (initialized) {
            return;
        }
        Security.addProvider(new BouncyCastleProvider());
        initialized = true;
    }

    /**
     * 生成iv
     */
    private static AlgorithmParameters generateIV(byte[] iv) throws Exception {
        AlgorithmParameters params = AlgorithmParameters.getInstance("AES");
        params.init(new IvParameterSpec(iv));
        return params;
    }


}
