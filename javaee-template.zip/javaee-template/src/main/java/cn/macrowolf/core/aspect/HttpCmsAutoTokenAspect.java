package cn.macrowolf.core.aspect;

import cn.macrowolf.model.vo.common.TokenVO;
import cn.macrowolf.orm.mybatis.common.TokenMapper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author CatalpaFlat
 * @date Created in 2018/12/12 5:39 PM
 */
@Slf4j
@Aspect
@Order(3)
@Component
public class HttpCmsAutoTokenAspect extends AbstractAuthTokenAspect {
    @Resource
    private TokenMapper tokenMapper;

    /**
     * 切面
     */
    private final String POINT_CUT = "execution(* cn.macrowolf.idal..*(..))";

    @Pointcut(POINT_CUT)
    private void pointcut() {
    }

    @Around(POINT_CUT)
    public Object before(ProceedingJoinPoint joinPoint) {
        return super.validateToken(joinPoint);
    }

    @Override
    protected TokenVO obtainAccountTokenInfoByAccessToken(String accessToken) {
        return tokenMapper.queryTokenInfoByAccessToken(accessToken);
    }
}
