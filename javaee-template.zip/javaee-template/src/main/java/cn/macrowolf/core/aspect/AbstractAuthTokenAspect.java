package cn.macrowolf.core.aspect;

import cn.macrowolf.core.annotation.IgnoreToken;
import cn.macrowolf.core.constant.HttpMessageConstant;
import cn.macrowolf.core.support.http.AbstractHttpSupport;
import cn.macrowolf.core.support.http.HttpResponseSupport;
import cn.macrowolf.model.vo.common.TokenVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

/**
 * @author CatalpaFlat
 * @date Created in 2018/6/30 下午3:33
 */
@Slf4j
@Aspect
@Order(2)
@Component
public abstract class AbstractAuthTokenAspect {

    public Object validateToken(ProceedingJoinPoint joinPoint) {
        //获取当前执行的方法
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        //判断当前执行的方法是否存在自定义的注解
        if (signature.getMethod().isAnnotationPresent(IgnoreToken.class)) {
            //只需要过滤登录即可，所以考虑在登录方法上加上注解，存在注解的就不验证token，不存在注解的需要验证
            try {
                return joinPoint.proceed();
            } catch (Throwable throwable) {
                log.error("{}", throwable.getMessage());
                return HttpResponseSupport.error(HttpStatus.INTERNAL_SERVER_ERROR, HttpMessageConstant.HTTP_MESSAGE_INTERNAL_SERVER_ERROR, "拦截错误");
            }
        }

        //获取 request response 对象
        ServletRequestAttributes res = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = res.getRequest();
        HttpServletResponse response = res.getResponse();

        String token = request.getHeader("X-Access-Token");
        log.info("token：{}", token);
        //token为空
        if (StringUtils.isBlank(token)) {
            log.error("提交的X-Access-Token empty，isBlank，{}", token);
            try {
                AbstractHttpSupport.intercept(request, response, joinPoint);
            } catch (Exception e) {
                log.error("{}", e.getMessage());
            }
            return HttpResponseSupport.error(HttpStatus.PRECONDITION_FAILED, HttpMessageConstant.HTTP_MESSAGE_PRECONDITION_FAILED, "X-Access-Token Defect");
        }

        //实现查询token是否有效/存在
        TokenVO tokenVO = obtainAccountTokenInfoByAccessToken(token);
        if (tokenVO == null) {
            log.error("提交的X-Access-Token empty，无效，数据库中不存在，{}", token);
            try {
                AbstractHttpSupport.intercept(request, response, joinPoint);
            } catch (Exception e) {
                log.error("{}", e.getMessage());
            }
            return HttpResponseSupport.error(HttpStatus.UNAUTHORIZED, HttpMessageConstant.HTTP_MESSAGE_UNAUTHORIZED, "X-Access-Token invalid");
        }

        if (this.verifyTokenIsExpires(tokenVO)) {
            log.error("提交的token已过期，{}", token);
            try {
                AbstractHttpSupport.intercept(request, response, joinPoint);
            } catch (Exception e) {
                log.error("{}", e.getMessage());
            }
            return HttpResponseSupport.error(HttpStatus.UNAUTHORIZED, HttpMessageConstant.HTTP_MESSAGE_UNAUTHORIZED, "X-Access-Token expire");
        }

        try {
            return joinPoint.proceed();
        } catch (Throwable throwable) {
            log.error("{}", throwable.getMessage());
            return HttpResponseSupport.error(HttpStatus.INTERNAL_SERVER_ERROR, HttpMessageConstant.HTTP_MESSAGE_INTERNAL_SERVER_ERROR, throwable.getMessage());
        }
    }

    protected abstract TokenVO obtainAccountTokenInfoByAccessToken(String accessToken);


    private boolean verifyTokenIsExpires(TokenVO tokenVO) {
        //检测是否过期
        Long expiresTime = tokenVO.getExpires_time();
        Date createTime = tokenVO.getCreate_time();

        Date updateTime = tokenVO.getUpdate_time();
        long time;
        if (updateTime != null) {
            time = new Date(updateTime.getTime() + expiresTime).getTime();
        } else {
            time = new Date(createTime.getTime() + expiresTime).getTime();
        }
        long currentTimeMillis = System.currentTimeMillis();
        //是否过期
        return currentTimeMillis > time;
    }
}
