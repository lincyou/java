package cn.macrowolf.core.utils;

import com.google.gson.Gson;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.UploadManager;
import com.qiniu.storage.model.DefaultPutRet;
import com.qiniu.util.Auth;
import lombok.extern.slf4j.Slf4j;

/**
 * @author CatalpaFlat
 * @date Created in 2018/12/10 5:15 PM
 */
@Slf4j
public class QNUtils {
    /**
     * 七牛云所需云依赖
     * <qiniu.version>0.1.4</qiniu.version>
     * <qiniu.java.version>[7.2.0, 7.2.99]</qiniu.java.version>
     * <dependency>
     * <groupId>com.qiniu</groupId>
     * <artifactId>happy-dns-java</artifactId>
     * <version>${qiniu.version}</version>
     * <scope>compile</scope>
     * </dependency>
     * <dependency>
     * <groupId>com.qiniu</groupId>
     * <artifactId>qiniu-java-sdk</artifactId>
     * <version>${qiniu.java.version}</version>
     * </dependency>
     */

    public static String upload(String accessKey, String secretKey, String bucket, String domain, byte[] bytes) {
        Auth auth = Auth.create(accessKey, secretKey);
        String upToken = auth.uploadToken(bucket);
        Configuration cfg = new Configuration(Zone.zone2());
        UploadManager uploadManager = new UploadManager(cfg);
        com.qiniu.http.Response qnResponse = null;
        try {
            qnResponse = uploadManager.put(bytes, null, upToken);
            //解析上传成功的结果
            DefaultPutRet putRet = new Gson().fromJson(qnResponse.bodyString(), DefaultPutRet.class);
            String key = putRet.key;
            log.info("key:" + putRet.key);
            return domain + key;
        } catch (QiniuException e) {
            e.printStackTrace();
        }
        return null;
    }
}
