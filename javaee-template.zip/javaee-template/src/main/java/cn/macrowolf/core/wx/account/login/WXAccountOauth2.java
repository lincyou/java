package cn.macrowolf.core.wx.account.login;

import lombok.extern.slf4j.Slf4j;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/8 10:37 AM
 */
@Slf4j
public class WXAccountOauth2 {

    private static final String APP_ID_STR = "APP_ID";

    private static final String REDIRECT_URI_STR = "REDIRECT_URI";

    private static final String SCOPE_STR = "SCOPE";

    private static final String OAUTH_URL = "https://open.weixin.qq.com/connect/oauth2/authorize?" +
            "appid=" + APP_ID_STR +
            "&redirect_uri=" + REDIRECT_URI_STR +
            "&response_type=code&scope=" + SCOPE_STR +
            "&state=STATE#wechat_redirect";


    public static String oauth2Url(String appId, String scope, String redirectUri) {
        try {
            String url = URLEncoder.encode(redirectUri, "utf-8");

            return OAUTH_URL.replace(APP_ID_STR, appId)
                    .replace(REDIRECT_URI_STR, url)
                    .replace(SCOPE_STR, scope);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
