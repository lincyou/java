package cn.macrowolf.core.support.qn;

import com.qiniu.util.Auth;
import lombok.extern.slf4j.Slf4j;

import static cn.macrowolf.core.property.QNProperty.ACCESS_KEY;
import static cn.macrowolf.core.property.QNProperty.BUCKET;
import static cn.macrowolf.core.property.QNProperty.SECRET_KEY;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/29 2:12 PM
 */
@Slf4j
public final class QNSupport {

    private QNSupport() {
    }

    /**
     * 获取七牛凭证token
     *
     * @return 凭证token
     */
    public static String obtainQNToken() {
        Auth auth = Auth.create(ACCESS_KEY, SECRET_KEY);
        return auth.uploadToken(BUCKET);
    }
}
