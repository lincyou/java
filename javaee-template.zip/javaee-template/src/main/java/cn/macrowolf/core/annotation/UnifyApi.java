package cn.macrowolf.core.annotation;

import cn.macrowolf.model.vo.common.error.ErrorVO;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/29 2:23 PM
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@ApiResponses({
        @ApiResponse(code = 500, message = "服务器异常", response = ErrorVO.class),
        @ApiResponse(code = 404, message = "账号密码错误", response = ErrorVO.class),
        @ApiResponse(code = 401, message = "鉴权失败", response = ErrorVO.class),
        @ApiResponse(code = 412, message = "请求头有误", response = ErrorVO.class),
})
public @interface UnifyApi {
}
