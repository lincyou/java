package cn.macrowolf.core.wx.account.login;

import cn.macrowolf.core.support.http.HttpGetSupport;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;

import static cn.macrowolf.core.wx.constant.WXConstant.ACCESS_TOKEN;
import static cn.macrowolf.core.wx.constant.WXConstant.ERRCODE;
import static cn.macrowolf.core.wx.constant.WXConstant.OPEN_ID;


/**
 * @author CatalpaFlat
 * @date Created in 2019/1/8 10:40 AM
 */
@Slf4j
public class WXAccountLogin {

    private static final String ACCOUNT_LOGIN = "https://api.weixin.qq.com/sns/oauth2/access_token";
    private static final String USER_INFO_URL = "https://api.weixin.qq.com/sns/userinfo";

    public static JSONObject obtainUserInfo(String code, String appId, String secret) {
        JSONObject accessTokenJson = obtainAccessTokenFromWX(code, appId, secret);
        String openId = obtainOpenId(accessTokenJson);
        String accessToken = obtainAccessToken(accessTokenJson);
        return obtainUserInfo(accessToken, openId);
    }

    public static JSONObject obtainAccessTokenFromWX(String code, String appId, String secret) {
        String url = obtainAccountLoginUrl(code, appId, secret);
        String result = HttpGetSupport.get(url);
        if (result == null) {
            return null;
        }
        JSONObject resultJson = JSONObject.fromObject(result);
        if (resultJson.containsKey(ERRCODE)) {
            log.error("微信扫码登录，错误,msg:{}", resultJson.getString("errmsg"));
            return null;
        }
        /*
        {
            "access_token":"ACCESS_TOKEN",
            "expires_in":7200,
            "refresh_token":"REFRESH_TOKEN",
            "openid":"OPENID",
            "scope":"SCOPE"
        }
         */
        return resultJson;
    }


    private static String obtainAccountLoginUrl(String code, String appId, String secret) {
        return ACCOUNT_LOGIN +
                "?appid=" +
                appId +
                "&secret=" +
                secret +
                "&code=" +
                code +
                "&grant_type=authorization_code";
    }

    private static String obtainUserInfoUrl(String accessToken, String openId) {
        return USER_INFO_URL +
                "?access_token=" +
                accessToken +
                "&openid=" +
                openId;
    }

    private static String obtainOpenId(JSONObject json) {
        if (json == null) {
            return null;
        }
        if (!json.containsKey(OPEN_ID)) {
            return null;
        }
        return json.getString(OPEN_ID);
    }

    private static String obtainAccessToken(JSONObject json) {
        if (json == null) {
            return null;
        }
        if (!json.containsKey(ACCESS_TOKEN)) {
            return null;
        }
        return json.getString(ACCESS_TOKEN);
    }

    public static JSONObject obtainUserInfo(String accessToken, String openId) {
        assert accessToken != null;
        assert openId != null;

        String url = obtainUserInfoUrl(accessToken, openId);
        String result = HttpGetSupport.get(url);
        if (result == null) {
            return null;
        }
        JSONObject resultJson = JSONObject.fromObject(result);
        if (resultJson.containsKey(ERRCODE)) {
            log.error("微信扫码获取用户信息，错误,msg:{}", resultJson.getString("errmsg"));
            return resultJson;
        }
        /*
            {
                "openid":"OPENID",
                "nickname":"NICKNAME",
                "sex":1,
                "province":"PROVINCE",
                "city":"CITY",
                "country":"COUNTRY",
                "headimgurl": "http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/0",
                "privilege":[
                "PRIVILEGE1",
                "PRIVILEGE2"
                ],
                "unionid": " o6_bmasdasdsad6_2sgVt7hMZOPfL"
            }
         */
        return resultJson;
    }
}
