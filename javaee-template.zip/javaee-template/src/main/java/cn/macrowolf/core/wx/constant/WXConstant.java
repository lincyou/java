package cn.macrowolf.core.wx.constant;

/**
 * @author CatalpaFlat
 * @date Created in 2018/12/7 3:35 PM
 */
public class WXConstant {
    public static final String APP_ID_STR = "APPID";
    public static final String SECRET_STR = "SECRET";
    public static final String CODE_STR = "code";
    public static final String ACCESS_TOKEN_STR = "ACCESSTOKEN";
    public static final String OPEN_ID_STR = "OPENID";

    public static final String ERRCODE = "errcode";
    public static final String OPEN_ID = "openid";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String NICK_NAME = "nickName";
    public static final String HEAD_IMG_URL = "headimgurl";
    public static final String UNIONID = "unionid";
    public static final String SESSION_KEY = "session_key";
    public static final String AVATAR_URL = "avatarUrl";


    public static final String WX_PAY_RERUEN_CODE = "return_code";
    public static final String WX_PAY_RESULT_CODE = "result_code";
    public static final String WX_PAY_CODE_URL = "code_url";
    public static final String WX_PAY_SUCCESS = "SUCCESS";



    /*--------------------------------------- 微信支付参数 ---------------------------------------------*/

    public static final String BODY_STR = "body";
    public static final String OUT_TRADE_NO_STR = "out_trade_no";
    public static final String FEE_TYPE_STR = "fee_type";
    public static final String TOTAL_FEE_STR = "total_fee";
    public static final String SPBILL_CREATE_IP_STR = "spbill_create_ip";
    public static final String NOTIFY_URL_STR = "notify_url";
    public static final String TRADE_TYPE_STR = "trade_type";
    public static final String ATTACH_STR = "attach";

}