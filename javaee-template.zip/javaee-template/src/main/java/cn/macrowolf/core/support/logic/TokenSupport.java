package cn.macrowolf.core.support.logic;

import cn.macrowolf.core.utils.DateUtil;
import cn.macrowolf.core.utils.MD5Util;
import cn.macrowolf.orm.mybatis.common.TokenMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

import static cn.macrowolf.core.constant.SystemConstant.SYSTEM_TOKEN_NAME;


/**
 * @author CatalpaFlat
 * @date Created in 2019/1/29 2:09 PM
 */
@Slf4j
public final class TokenSupport {
    private TokenSupport() {
    }

    public static final String TOKEN_ACCESS_TOKEN_STR = "access_token";
    public static final String TOKEN_REFRESH_TOKEN_STR = "refresh_token";
    public static final String TOKEN_EXPIRES_TIME_STR = "expires_time";

    /**
     * 根据accessToken获取账号uuid
     *
     * @param tokenMapper mapper
     * @return 账号uuid
     */
    public static String obtainAccountUuidByAccessToken(TokenMapper tokenMapper) {
        //获取 request response 对象
        ServletRequestAttributes res = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = res.getRequest();

        String token = request.getHeader(SYSTEM_TOKEN_NAME);

        log.info("token：{}", token);

        return tokenMapper.queryAccountUuidByAccessToken(token);
    }


    public static Map<String, Object> obtainToken(Map<String, Object> map, String uuid) {
        String accessToken = MD5Util.makeToken(uuid, DateUtil.now());
        String refreshToken = MD5Util.makeToken(accessToken, DateUtil.now());
        long expiresTime = 60 * 60 * 24 * 30 * 100;
        map.put(TOKEN_ACCESS_TOKEN_STR, accessToken);
        map.put(TOKEN_REFRESH_TOKEN_STR, refreshToken);
        map.put(TOKEN_EXPIRES_TIME_STR, expiresTime);
        return map;
    }
}
