package cn.macrowolf.core.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
* @Author : WeiTong
* @Date :  2018/7/25 21:41
*/
public class DateUtil {

    public static String now(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
        return sdf.format(new Date());
    }

    public static String nowNotString(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return sdf.format(new Date());
    }
    public static String formatDateToString(Date date, String format){
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(date);
    }

    /**
     * 字符串转换成日期
     * @param str
     * @return date
     */
    public static Date strToDate(String str, String format) {

        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Date date = null;
        try {
            date = sdf.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public static boolean compare(String time1,String time2) throws ParseException {
        //如果想比较日期则写成"yyyy-MM-dd"就可以了
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        //将字符串形式的时间转化为Date类型的时间
        Date a=sdf.parse(time1);
        Date b=sdf.parse(time2);
        //Date类的一个方法，如果a早于b返回true，否则返回false
       return compare(a,b);
    }

    public static boolean compare(Date a,Date b) throws ParseException {

        int result = a.compareTo(b);
        if(result==0 || result ==-1){
            return true;
        }else{
            return false;
        }

    }

    public static boolean compareMillisecond(Long a,Long b) throws ParseException {

		//将Date转换成毫秒

		if(a-b<0){
            return true;
        }else{
            return false;
        }
    }

}
