package cn.macrowolf.core.property;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/29 10:57 AM
 */
@Component
public class QNProperty {
    public static String ACCESS_KEY;
    public static String SECRET_KEY;
    public static String BUCKET;
    public static String DOMAIN;

    @Value("${qn.access.key}")
    public void setACCESS_KEY(String access_key) {
        ACCESS_KEY = access_key;
    }

    @Value("${qn.secret.key}")
    public void setSECRET_KEY(String secret_key) {
        SECRET_KEY = secret_key;
    }

    @Value("${qn.bucket}")
    public void setBUCKET(String bucket) {
        BUCKET = bucket;
    }

    @Value("${qn.domain}")
    public void setDOMAIN(String domain) {
        DOMAIN = domain;
    }

}
