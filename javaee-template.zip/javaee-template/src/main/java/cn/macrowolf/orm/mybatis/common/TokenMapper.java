package cn.macrowolf.orm.mybatis.common;

import cn.macrowolf.model.vo.common.TokenVO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/29 11:08 AM
 */
@Repository
public interface TokenMapper {

    /**
     * 通过accessToken查询用户uuid
     *
     * @param accessToken 凭证
     * @return 用户uuid
     */
    String queryAccountUuidByAccessToken(@Param("access_token") String accessToken);

    /**
     * 根据accessToken查询token信息
     *
     * @param accessToken 凭证
     * @return token信息
     */
    TokenVO queryTokenInfoByAccessToken(@Param("access_token") String accessToken);

    /**
     * 更新凭证信息
     *
     * @param map 凭证信息
     */
    void updateTokenInfo(Map<String, Object> map);

    /**
     * 新增凭证信息
     *
     * @param map 凭证信息
     */
    void insertToken(Map<String, Object> map);

    /**
     * 根据管理员uuid查询token
     *
     * @param uuid 管理员uuid
     * @return token
     */
    TokenVO queryAdminTokenByAdminUuid(@Param("uuid") String uuid);
}
