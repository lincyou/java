package cn.macrowolf.model.vo.common;


import lombok.Data;

import javax.persistence.*;

/**
 * @author CatalpaFlat
 * @date Created in 2019/2/12 2:09 PM
 */
@Data
@Entity
@Table(name = "token")
public class TempVO {
    @Id
    @GeneratedValue
    @Column(nullable = false, name = "id")
    private Long id;
}
