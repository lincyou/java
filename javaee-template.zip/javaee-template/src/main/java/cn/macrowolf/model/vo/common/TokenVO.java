package cn.macrowolf.model.vo.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/29 11:40 AM
 */
@Data
@ApiModel(value = "Token", description = "凭证")
public class TokenVO {

    @ApiModelProperty(value = "uuid", name = "凭证uuid", required = true, dataType = "string")
    private String uuid;

    @ApiModelProperty(value = "account_uuid", name = "账号关联uuid", required = true, dataType = "string")
    private String account_uuid;

    @ApiModelProperty(value = "access_token", name = "凭证", required = true, dataType = "string")
    private String access_token;

    @ApiModelProperty(value = "refresh_token", name = "刷新凭证", required = true, dataType = "string")
    private String refresh_token;

    @ApiModelProperty(value = "expires_time", name = "有效时长", required = true, dataType = "Long")
    private Long expires_time;

    @ApiModelProperty(value = "create_time", name = "创建时间", required = true, dataType = "string")
    private Date create_time;

    @ApiModelProperty(value = "update_time", name = "更新时间", required = true, dataType = "string")
    private Date update_time;
}
