package cn.macrowolf.model.vo.common.error;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/2 5:15 PM
 */
@Data
@ApiModel(value = "error-info", description = "error-info")
class ErrorInfoVO {
    @ApiModelProperty(value = "type", name = "类型", required = true, dataType = "string", example = "error type")
    private String type;

    @ApiModelProperty(value = "message", name = "内容", required = true, dataType = "string",example = "error message")
    private String message;

    @ApiModelProperty(value = "reason", name = "详情/国际化", required = true, dataType = "string",  example = "error detail or internationalization")
    private String reason;
}
