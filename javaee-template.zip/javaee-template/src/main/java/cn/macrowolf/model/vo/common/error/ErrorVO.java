package cn.macrowolf.model.vo.common.error;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author CatalpaFlat
 * @date Created in 2019/1/2 5:15 PM
 */
@Data
@ApiModel(value = "error", description = "error")
public class ErrorVO {
    @ApiModelProperty(value = "error", name = "错误信息", required = true)
    private ErrorInfoVO error;
}
