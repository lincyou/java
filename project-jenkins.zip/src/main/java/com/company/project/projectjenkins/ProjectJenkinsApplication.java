package com.company.project.projectjenkins;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class ProjectJenkinsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectJenkinsApplication.class, args);
	}

	@RequestMapping("/hello")
	public Object helloWorld(){
		return "hello world1.0.1";
	}
}
